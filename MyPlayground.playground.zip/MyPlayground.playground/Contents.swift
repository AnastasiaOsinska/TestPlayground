import UIKit

// - Task 1 -

let greeting = "Els Elds Elds"
let str = ""

extension String {
    func indexFor(search: String) -> Int? {
        guard !search.isEmpty else { return nil }
        var offset: Int = 0
        for (index, element) in enumerated() {
            offset = (element == search[.init(utf16Offset: offset, in: search)]) ? (offset + 1) : 0
            guard search.count != offset else {
                return index - offset + 1
            }
        }
        return nil
    }
}

print(greeting.indexFor(search: str) ?? "nil")


// - Task 2 -

enum MinMaxError: Error {
    case emptyInput
    var localizedDescription: String {
        switch self {
        case .emptyInput:
            return "empty array"
        }
    }
}

extension Array where Element: Comparable {
    func minMax() throws {
        guard let first = first else { throw MinMaxError.emptyInput }
        var (min, max) = (first, first)
        forEach {
            min = $0 < min ? $0 : min
            max = $0 > max ? $0 : max
        }
        print("min: \(min), max: \(max)")
    }
}

do {
    try [4.00, 89, -3, 56, -4, 1, 10, 89].minMax()
} catch MinMaxError.emptyInput {
    print(MinMaxError.emptyInput.localizedDescription)
}

