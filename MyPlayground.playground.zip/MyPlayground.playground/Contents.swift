import UIKit

// - Task 1 -

let greeting = "Els Elds Elds"
let str = "elds"


extension String {
    func indexFor(search: String) -> Int? {
        var offset: Int = 0
        for (index, element) in enumerated() {
            offset = (element == search[.init(utf16Offset: offset, in: search)]) ? (offset + 1) : 0
            guard search.count - 1 != offset else {
                return index - offset + 1
            }
        }
        return nil
    }
}

print(greeting.indexFor(search: str) ?? "nil")



// - Task 2 -

extension Array where Element == Int {
    func minMax() -> Void {
        var max = self[0]
        var min = self[0]
        for element in self {
            min = element < min ? element : min
            max = element > max ? element : max
        }
        print("min: \(min), max: \(max)")
    }
}

[4, 89, -3, 56, -4, 1, 10, 89].minMax()
